# ISA100Forge Pro - Technical Architecture & Protocol Specification

## 1. Executive Summary & Purpose
**ISA100Forge Pro** is an industrial wireless mesh protocol engineering suite specifically targeted at **ISA100.11a (IEC 62734 / IEEE 802.15.4)** wireless sensor networks. ISA100.11a is the leading open industrial wireless mesh standard deployed across oil & gas refineries, offshore drilling platforms, chemical manufacturing plants, and tank farm monitoring facilities (Yokogawa Centum/ProSafe-RS, Honeywell OneWireless).
This suite addresses critical engineering bottlenecks:
1. **IEEE 802.15.4 Physical Layer & MAC Framing**: Assembles and validates 2.4 GHz Direct Sequence Spread Spectrum (DSSS) O-QPSK frames, 4-byte preambles (`0x00000000`), Start of Frame Delimiters (`0xA7`), Frame Control Fields (`0x8861`), and 16-bit CRC FCS ($x^{16} + x^{12} + x^5 + 1$).
2. **Cryptographic Security Layer**: Implements AES-128 CCM* authenticated encryption with 32-bit Message Integrity Codes (MIC-32) to enforce cyber protection across untrusted radio environments.
3. **TDMA Superframe & 16-Channel Hopping Scheduler**: Sequences 10.0 ms timeslot templates (Radio lock, Clear Channel Assessment, 250 kbps transmission, turnaround, immediate ACK, and deep sleep) across 16 DSSS channels (2405 MHz to 2480 MHz).
4. **RF Link Budget & Battery Life Sizer**: Models heavy industrial log-distance path loss ($n = 3.4$), Fresnel zone clearances, and 19.0 Ah Lithium Thionyl Chloride ($\text{Li-SOCl}_2$) cell discharge profiles to verify NAMUR NE 124 $\ge 5$-year battery maintenance targets.
5. **10-Point Mesh Safety Auditor**: Enforces short address uniqueness (`0x0002..0xFFFD`), Subnet PAN ID alignment, RF fade margin thresholds ($\ge 15\text{ dB}$), mesh path diversity ($\ge 2$ routing parents), and Redundant System Manager readiness.
6. **Multi-Target Exporter**: Outputs Yokogawa YFGW410/YFGW510 Gateway provisioning XML, Honeywell OneWireless network CSVs, and Python IEEE 802.15.4 packet simulation scripts.

---

## 2. Standards & Physical Layer Specifications
- **ISA100.11a / IEC 62734**: Wireless systems for industrial automation: Process control and related applications.
- **IEEE 802.15.4-2006**: Low-Rate Wireless Personal Area Networks (LR-WPANs) — 2.4 GHz PHY & MAC.
- **RF Spectrum**: 16 non-overlapping channels in the 2.4 GHz ISM band ($2405\text{ MHz} + 5 \times (k - 11)$ for $k = 11..26$).
- **Modulation**: Offset Quadrature Phase Shift Keying (O-QPSK) with half-sine pulse shaping, 2.0 Mchips/s chipping rate, raw data rate $250\text{ kbps}$ ($32\ \mu\text{s/byte}$, $4\ \mu\text{s/bit}$).
- **Security**: AES-128 CCM* (Counter with CBC-MAC) link-layer and transport-layer encryption.

---

## 3. Physical Frame Structure

```
+---------------+------+-----+---------+---------+--------+---------+--------+--------+--------+
| Preamble (4B) | SFD  | PHR | FCF (2) | Seq (1) | PAN ID | Dst (2) | Src (2)| App PDU| MIC-32 | FCS(2) |
+---------------+------+-----+---------+---------+--------+---------+--------+--------+--------+
   0x00000000    0xA7   Len    0x8861     0..255   16 bits   16 bits  16 bits  Var Data 4 bytes  0x1021
```
- **Preamble**: 4 bytes of `0x00` (Manchester / DSSS chip synchronization).
- **Start of Frame Delimiter (SFD)**: `0xA7` (Symbol `1110 0101`).
- **PHY Header (PHR)**: 1 byte frame length (7-bit length, max 127 bytes).
- **MAC FCF**: `0x8861` (Data frame, security enabled, ACK requested, short 16-bit addressing).
- **MIC-32**: 4 bytes AES-128 CCM* Message Integrity Code for cryptographic authentication.
- **FCS**: 16-bit ITU-T CRC polynomial $x^{16} + x^{12} + x^5 + 1$.

---

## 4. RF Link Budget & Battery Life Mathematical Models

### Industrial Path Loss Model
In dense steel/piping environments (refinery piperacks, chemical distillation columns):
$$\text{PL}(d) = 40.23 + 10 \cdot n \cdot \log_{10}(d)$$
Where:
- $n = 3.4$ (Heavy industrial clutter)
- $\text{RSSI} = P_{\text{TX}} + G_{\text{TX}} + G_{\text{RX}} - \text{PL}(d) = 10\text{ dBm} + 2.5\text{ dBi} + 2.5\text{ dBi} - \text{PL}(d)$
- $\text{Link Margin} = \text{RSSI} - (-95.0\text{ dBm sensitivity}) \ge 15.0\text{ dB}$

### Battery Longevity Model ($\text{Li-SOCl}_2$)
$$I_{\text{avg}} = \frac{E_{\text{burst}}}{T_{\text{publish}}} + I_{\text{sleep}}$$
Where:
- $E_{\text{burst}} = (35\text{ mA} \times 4.5\text{ ms}) + (25\text{ mA} \times 2.0\text{ ms}) = 207.5\ \mu\text{A}\cdot\text{s}$
- $I_{\text{sleep}} = 4.2\ \mu\text{A}$
- Operational Lifetime:
$$\text{Years} = \frac{C_{\text{battery}}\text{ (mAh)}}{I_{\text{avg}}\text{ (mA)} \times 8760\text{ hours/year}} \times 0.88\text{ (derating factor)}$$
For a 19.0 Ah D-cell publishing every 10 seconds:
$$I_{\text{avg}} = \frac{207.5}{10} + 4.2 = 24.95\ \mu\text{A} = 0.02495\text{ mA}$$
$$\text{Years} = \frac{19000}{0.02495 \times 8760} \times 0.88 \approx 76.5\text{ years} \rightarrow \text{capped at 20.0 years (cell shelf-life)}$$
For a 1-second interval, longevity is $\approx 9.5\text{ years}$.
