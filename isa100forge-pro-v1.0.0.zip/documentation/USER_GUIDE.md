# ISA100Forge Pro - User Guide & Operator Manual

## 1. Quick Start
To launch the interactive web studio:
1. Open `product_200/source-code/index.html` in any modern web browser.
2. All calculations and protocol packet dissections execute completely client-side with zero external internet dependencies or complex installations.

To use the standalone Python CLI:
```bash
# Make CLI executable
chmod +x product_200/build/isa100-cli.py

# Build an ISA100.11a Data Packet for Node 0x0014 publishing PV = 75.0
./product_200/build/isa100-cli.py packet-build --pan 0x100A --src 0x0014 --dest 0x0001 --pv 75.0

# Dissect an over-the-air packet hex stream
./product_200/build/isa100-cli.py packet-dissect "00 00 00 00 A7 16 61 88 2A 0A 10 01 00 14 00 05 00 42 96 00 00 80 F7 A6 3C C2 CB 6C"

# Calculate RF Link Budget & Battery Longevity
./product_200/build/isa100-cli.py rf-size --dist 50 --env HEAVY_INDUSTRIAL --interval 10

# Run 10-Point Mesh Safety Auditor
./product_200/build/isa100-cli.py audit --devices '[{"addr":1,"name":"Gateway","router":true,"sm":true},{"addr":20,"name":"PT-1","router":false,"parents":2}]' --dist 40
```

---

## 2. Workbench Tabs & Capabilities

### Tab 1: 802.15.4 Packet Builder & MIC-32
- Compose complete over-the-air DSSS packets with Subnet PAN ID, Short Address headers, sequence counters, and process values.
- Formats standard 4-byte preambles, `0xA7` SFD, MAC Frame Control Fields (`0x8861`), and calculates 32-bit AES-128 Message Integrity Codes (MIC-32).
- Immediate hex byte stream visualization and layer-by-layer dissection.

### Tab 2: TDMA Superframe Scheduler
- Add, edit, and configure mesh communication links between field transmitters, mesh routers, and the gateway.
- Sequences 10.0 ms timeslot templates across 16 DSSS channels (2405 MHz to 2480 MHz).
- Visualizes timeslot utilization percentages and radio sleep duty cycles ($> 95\%$).

### Tab 3: RF Path Loss & Battery Sizer
- Select industrial propagation environments (Heavy Industrial, Light Industrial, Free Space) and enter link distance.
- Computes received signal strength (RSSI), Fresnel zone radius clearance, and RF Link Fade Margin ($\ge 15\text{ dB}$).
- Models Lithium Thionyl Chloride ($\text{Li-SOCl}_2$) cell discharge to predict operating lifespan in years.

### Tab 4: 10-Point Mesh Safety Auditor
- Pre-commissioning verification:
  - Short address uniqueness and collision protection.
  - Subnet PAN ID consistency across all nodes.
  - RF fade margin thresholds ($\ge 15\text{ dB}$).
  - Mesh path diversity ($\ge 2$ routing parents per leaf node).
  - AES-128 CCM* encryption and MIC-32 verification.
  - NAMUR NE 124 battery longevity ($\ge 3$ years).
  - Clear Channel Assessment (CCA) collision avoidance.
  - Redundant System Manager readiness.

### Tab 5: Yokogawa & Honeywell Exporter
- Outputs Yokogawa YFGW410 / YFGW510 field wireless gateway XML provisioning files.
- Generates Honeywell OneWireless device provisioning CSV tables.
- Outputs Python 3 IEEE 802.15.4 packet simulation scripts.
