# ISA100Forge Pro - Commercial & Monetization Strategy Playbook

## 1. Product Positioning & Market Demand
ISA100.11a (IEC 62734) is the premier open industrial wireless mesh standard deployed across major continuous process industries:
- **Upstream Oil & Gas & Offshore Platforms**: Shell, Chevron, ExxonMobil, ADNOC offshore wellhead and flare stack temperature monitoring.
- **Refining & Petrochemical Plants**: BASF, Dow, SABIC, Reliance distillation column pressure transmitters and rotating equipment vibration sensors.
- **Bulk Liquid Storage & Tank Farms**: Vopak, Kinder Morgan overfill protection and radar tank gauging where running physical copper cable costs $100-$300/meter.

### Key Engineering Pain Points Solved
- Proprietary gateway software tools (Yokogawa Field Wireless Configurator, Honeywell OneWireless Designer) are tied to expensive plant server licenses and difficult to deploy for on-site field surveys.
- Field instrument technicians installing new wireless transmitters struggle with RF multipath fading in dense metallic piperacks and frequently deploy transmitters with insufficient link fade margins (<15 dB).
- Single-parent mesh topologies leave transmitters vulnerable to signal blackouts when plant cranes or maintenance scaffolding block the line of sight.

**ISA100Forge Pro** provides a lightweight, zero-install, browser-based and CLI workbench for rapid link budget sizing, packet crafting, and automated mesh safety verification.

---

## 2. Pricing Tiers & Commercial Model

| Tier | Target Customer | Pricing | Key Inclusions |
| :--- | :--- | :--- | :--- |
| **Community Edition** | Students, apprentices, instrumentation techs | Free / Open Core | Packet Builder, Dissector, Basic RF Sizer, Web UI |
| **Professional License** | Instrumentation Leads, Wireless Survey Engineers | $299 one-time per seat | Full TDMA Superframe Allocator, 10-Point Safety Auditor, Python CLI, Yokogawa & Honeywell Exporters |
| **Plant Site License** | Refineries, Petrochemical Complexes, EPCs | $2,490 / site / year | Site-wide license, automated CI/CD mesh validation hooks, gateway provisioning generator, priority support |

---

## 3. Go-To-Market & Acquisition Channels
1. **Industrial Wireless & ISA Communities**: ISA Wireless Systems (ISA100 Committee), ControlGlobal, Automation.com, and Reddit r/PLC.
2. **Open Source SEO & Developer Tools**: GitHub repository for `isa100-cli.py` optimized for search terms: "ISA100 packet dissector", "IEC 62734 link budget calculator", "Yokogawa YFGW provisioning tool", "industrial 2.4 GHz path loss calculator".
3. **Process Instrumentation EPC Partnerships**: Direct engagement with instrumentation engineering departments at Bechtel, Fluor, Worley, and Technip Energies.
4. **Plant Maintenance Quick Reference Guides**: Distributable PDF cheat sheets on "ISA100.11a Mesh Design Rules & Battery Life Optimization" co-branded with ISA100Forge Pro.
