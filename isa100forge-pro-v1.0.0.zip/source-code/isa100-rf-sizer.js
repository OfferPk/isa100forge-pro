/**
 * ISA100Forge Pro - RF Link Budget & Battery Life Longevity Sizer
 * Calculates Log-Distance Path Loss in industrial plant environments,
 * Fresnel zone clearance, Link Margin (dBm), and battery life longevity (years)
 * based on Lithium Thionyl Chloride (Li-SOCl2) cell capacity (e.g. 19.0 Ah Tadiran).
 */

const ISA100RfSizer = (function () {
  // RF Physical Parameters @ 2.45 GHz
  const RF_CONSTANTS = {
    freqMhz: 2450.0,
    wavelengthM: 0.1224, // c / f = 3e8 / 2.45e9 = 0.1224 m
    txPowerDbm: 10.0,    // +10 dBm (10 mW standard industrial transmitter)
    antennaGainTxDbi: 2.5,// Omnidirectional stub antenna
    antennaGainRxDbi: 2.5,
    rxSensitivityDbm: -95.0, // Receiver sensitivity threshold
    fadeMarginRecommendedDb: 15.0
  };

  /**
   * Calculates Industrial Log-Distance Path Loss
   * PL(d) = PL(d0) + 10 * n * log10(d / d0) + X_sigma
   * In heavy industrial piping/tanks: path loss exponent n ≈ 3.2 to 3.8
   * Free-space: n ≈ 2.0
   */
  function calculatePathLoss(distanceMeters, environment = 'HEAVY_INDUSTRIAL') {
    const d = Math.max(1.0, distanceMeters);
    const n = (environment === 'FREE_SPACE') ? 2.0 : ((environment === 'LIGHT_INDUSTRIAL') ? 2.8 : 3.4);

    // Free space loss at reference distance d0 = 1 meter:
    // PL(1m) = 20 * log10(4 * pi * 1 / lambda) ≈ 40.2 dB @ 2.45 GHz
    const pl1m = 40.23;
    const pathLossDb = pl1m + (10 * n * Math.log10(d));

    // Received Signal Strength Indicator (RSSI in dBm)
    const rssiDbm = RF_CONSTANTS.txPowerDbm + RF_CONSTANTS.antennaGainTxDbi + RF_CONSTANTS.antennaGainRxDbi - pathLossDb;
    const linkMarginDb = rssiDbm - RF_CONSTANTS.rxSensitivityDbm;

    // 1st Fresnel Zone Radius at midpoint (meters)
    // r = 0.5 * sqrt(wavelength * distance)
    const fresnelRadiusM = 0.5 * Math.sqrt(RF_CONSTANTS.wavelengthM * d);

    return {
      distanceMeters: d,
      environment,
      pathLossExponent: n,
      pathLossDb: parseFloat(pathLossDb.toFixed(1)),
      rssiDbm: parseFloat(rssiDbm.toFixed(1)),
      linkMarginDb: parseFloat(linkMarginDb.toFixed(1)),
      fresnelRadiusM: parseFloat(fresnelRadiusM.toFixed(2)),
      isLinkReliable: linkMarginDb >= RF_CONSTANTS.fadeMarginRecommendedDb
    };
  }

  /**
   * Calculates Battery Life Longevity (Years)
   * Models Lithium Thionyl Chloride (Li-SOCl2) D-cell / AA-cell discharge.
   * Current draw breakdown:
   * - Active TX: ~35 mA for 4.5 ms per publish
   * - Active RX (Listen/ACK): ~25 mA for 2.0 ms per publish
   * - Deep Sleep: ~4.0 µA quiescent baseline
   * - Self-discharge: 1.0% per year
   */
  function calculateBatteryLife(publishIntervalSec = 10, batteryCapacityAh = 19.0) {
    const pubSec = Math.max(1, publishIntervalSec);
    const capacityMah = batteryCapacityAh * 1000.0;

    // Energy per publication transaction in micro-Ampere-seconds (µA·s):
    // TX: 35,000 µA * 0.0045 s = 157.5 µA·s
    // RX: 25,000 µA * 0.0020 s = 50.0 µA·s
    // Total per burst = ~207.5 µA·s
    const energyPerBurstUAs = 207.5;
    const avgBurstCurrentUa = energyPerBurstUAs / pubSec;

    // Background sleep current + RTC + crystal oscillator
    const sleepCurrentUa = 4.2;

    const totalAvgCurrentUa = avgBurstCurrentUa + sleepCurrentUa;
    const totalAvgCurrentMa = totalAvgCurrentUa / 1000.0;

    // Hours of operation = Capacity (mAh) / Avg Current (mA)
    const totalHours = capacityMah / totalAvgCurrentMa;
    const rawYears = totalHours / 8760.0;

    // Factor in cell passivation and 1.2% annual self-discharge
    const deratedYears = parseFloat((rawYears * 0.88).toFixed(1));

    return {
      publishIntervalSec: pubSec,
      batteryCapacityAh,
      totalAvgCurrentUa: parseFloat(totalAvgCurrentUa.toFixed(2)),
      totalAvgCurrentMa: parseFloat(totalAvgCurrentMa.toFixed(4)),
      estimatedLifetimeYears: Math.min(20.0, deratedYears),
      status: deratedYears >= 5.0 ? 'EXCELLENT_LIFETIME' : (deratedYears >= 2.0 ? 'ACCEPTABLE' : 'FREQUENT_REPLACEMENT')
    };
  }

  return {
    RF_CONSTANTS,
    calculatePathLoss,
    calculateBatteryLife
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ISA100RfSizer;
}
