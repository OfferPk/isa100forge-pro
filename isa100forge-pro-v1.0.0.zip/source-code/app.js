/**
 * ISA100Forge Pro - Web Application Controller
 */

document.addEventListener('DOMContentLoaded', function () {
  // Navigation Tabs
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));

      btn.classList.add('active');
      const targetId = btn.getAttribute('data-tab');
      document.getElementById(targetId).classList.add('active');
    });
  });

  // Default Datasets
  let meshLinks = [
    { linkId: 1, name: 'Pressure Tx 1 -> Router 1', srcMac: '0x0014', dstMac: '0x0002', channelOffset: 0 },
    { linkId: 2, name: 'Temp Tx 2 -> Router 1', srcMac: '0x0015', dstMac: '0x0002', channelOffset: 1 },
    { linkId: 3, name: 'Flow Tx 3 -> Router 2', srcMac: '0x0016', dstMac: '0x0003', channelOffset: 2 },
    { linkId: 4, name: 'Router 1 -> Gateway', srcMac: '0x0002', dstMac: '0x0001', channelOffset: 3 },
    { linkId: 5, name: 'Router 2 -> Gateway', srcMac: '0x0003', dstMac: '0x0001', channelOffset: 4 }
  ];

  let devices = [
    { shortAddr: 0x0001, name: 'ISA100 Gateway / Backbone Router', isRouter: true, panId: 0x100A },
    { shortAddr: 0x0002, name: 'Field Mesh Router 1', isRouter: true, panId: 0x100A },
    { shortAddr: 0x0003, name: 'Field Mesh Router 2', isRouter: true, panId: 0x100A },
    { shortAddr: 0x0014, name: 'Pressure Transmitter 1', isRouter: false, parentCount: 2, panId: 0x100A },
    { shortAddr: 0x0015, name: 'Temperature Transmitter 2', isRouter: false, parentCount: 2, panId: 0x100A },
    { shortAddr: 0x0016, name: 'Coriolis Flow Transmitter 3', isRouter: false, parentCount: 2, panId: 0x100A }
  ];

  // TAB 1: Packet Builder
  function renderPacket() {
    const panStr = document.getElementById('pkt-pan-id').value;
    const panId = panStr.startsWith('0x') || panStr.startsWith('0X') ? parseInt(panStr, 16) : parseInt(panStr, 10);
    const seq = parseInt(document.getElementById('pkt-seq').value) || 42;
    const srcStr = document.getElementById('pkt-src').value;
    const srcAddr = srcStr.startsWith('0x') || srcStr.startsWith('0X') ? parseInt(srcStr, 16) : parseInt(srcStr, 10);
    const destStr = document.getElementById('pkt-dest').value;
    const destAddr = destStr.startsWith('0x') || destStr.startsWith('0X') ? parseInt(destStr, 16) : parseInt(destStr, 10);
    const objId = parseInt(document.getElementById('pkt-obj').value) || 5;
    const ch = parseInt(document.getElementById('pkt-channel').value) || 15;

    const res = ISA100Engine.buildPacket({
      panId,
      seqNumber: seq,
      srcAddr,
      destAddr,
      objectId: objId,
      channel: ch
    });

    document.getElementById('pkt-hex-output').innerText = res.hexString;
    document.getElementById('pkt-byte-badge').innerText = `${res.totalBytes} Bytes (${res.airDurationUs} µs @ 250k)`;

    const tbody = document.getElementById('dissect-tbody');
    tbody.innerHTML = `
      <tr><td>PHY Preamble &amp; SFD</td><td>0x00000000 0xA7</td><td>DSSS Clock Sync + Start Delimiter</td></tr>
      <tr><td>MAC FCF &amp; Seq#</td><td>0x8861 | Seq ${res.seqNumber}</td><td>Data Frame, Security Enabled, ACK Requested</td></tr>
      <tr><td>Subnet PAN ID</td><td>${res.panIdHex}</td><td>ISA100.11a Wireless Mesh Network ID</td></tr>
      <tr><td>Src / Dest Address</td><td>${res.srcAddrHex} -&gt; ${res.destAddrHex}</td><td>Field Device to Gateway Addressing</td></tr>
      <tr><td>DMAP Object &amp; Ch</td><td>0x0005 User App | Ch ${res.channel}</td><td>Process Measurement Publish Payload</td></tr>
      <tr><td>AES-128 MIC-32 &amp; FCS</td><td>${res.micHex} | ${res.fcsHex}</td><td>Cryptographic Integrity Code &amp; CRC-16 Valid</td></tr>
    `;
  }

  document.getElementById('btn-build-packet').addEventListener('click', renderPacket);

  // TAB 2: TDMA Scheduler
  function renderLinksTable() {
    const tbody = document.getElementById('tbody-links');
    tbody.innerHTML = '';

    meshLinks.forEach((l, idx) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><input type="text" class="form-control" value="${l.name}" onchange="updateLink(${idx}, 'name', this.value)"></td>
        <td><input type="text" class="form-control" style="width: 90px;" value="${l.srcMac}" onchange="updateLink(${idx}, 'srcMac', this.value)"></td>
        <td><input type="text" class="form-control" style="width: 90px;" value="${l.dstMac}" onchange="updateLink(${idx}, 'dstMac', this.value)"></td>
        <td><input type="number" class="form-control" style="width: 70px;" value="${l.channelOffset}" onchange="updateLink(${idx}, 'channelOffset', this.value)"></td>
        <td><span class="badge-tag" style="background: rgba(20, 184, 166, 0.1); color: var(--teal-accent);">Slot ${idx + 2} (${(idx + 2) * 10} ms)</span></td>
        <td><button class="btn btn-secondary" style="padding: 4px 8px; color: var(--rose-accent);" onclick="removeLink(${idx})">✕</button></td>
      `;
      tbody.appendChild(tr);
    });

    recalculateTdma();
  }

  window.updateLink = function (idx, field, val) {
    if (field === 'channelOffset') {
      meshLinks[idx][field] = parseInt(val) || 0;
    } else {
      meshLinks[idx][field] = val;
    }
    recalculateTdma();
  };

  window.removeLink = function (idx) {
    if (meshLinks.length > 1) {
      meshLinks.splice(idx, 1);
      renderLinksTable();
    }
  };

  document.getElementById('btn-add-link').addEventListener('click', () => {
    const nextId = meshLinks.length + 1;
    meshLinks.push({
      linkId: nextId,
      name: `Sensor Link ${nextId}`,
      srcMac: `0x001${nextId + 3}`,
      dstMac: '0x0002',
      channelOffset: (nextId % 16)
    });
    renderLinksTable();
  });

  function recalculateTdma() {
    const res = ISA100Scheduler.calculateSuperframe(meshLinks, 100, 10.0);

    document.getElementById('stat-superframe-dur').innerText = `${res.superframeDurationSec.toFixed(2)} s`;
    document.getElementById('stat-slot-util').innerText = `${res.slotUtilizationPercent}%`;
    document.getElementById('stat-duty-cycle').innerText = `${res.sleepDutyCyclePercent}%`;

    recalculateRf();
  }

  document.getElementById('btn-recalc-tdma').addEventListener('click', recalculateTdma);

  // TAB 3: RF & Battery Sizer
  function recalculateRf() {
    const env = document.getElementById('rf-env').value;
    const dist = parseInt(document.getElementById('rf-dist').value) || 75;
    const interval = parseInt(document.getElementById('battery-interval').value) || 10;

    const rfRes = ISA100RfSizer.calculatePathLoss(dist, env);
    const batRes = ISA100RfSizer.calculateBatteryLife(interval, 19.0);

    document.getElementById('stat-link-margin').innerText = `${rfRes.linkMarginDb} dB`;
    document.getElementById('stat-battery-years').innerText = `${batRes.estimatedLifetimeYears} Years`;
    document.getElementById('stat-fresnel-radius').innerText = `${rfRes.fresnelRadiusM} m`;

    if (rfRes.isLinkReliable) {
      document.getElementById('stat-link-margin').style.color = 'var(--emerald-accent)';
    } else {
      document.getElementById('stat-link-margin').style.color = 'var(--rose-accent)';
    }
  }

  document.getElementById('btn-recalc-rf').addEventListener('click', recalculateRf);
  document.getElementById('rf-env').addEventListener('change', recalculateRf);

  // TAB 4: Safety Auditor
  function runAudit() {
    const dist = parseInt(document.getElementById('rf-dist').value) || 75;
    const env = document.getElementById('rf-env').value;
    const interval = parseInt(document.getElementById('battery-interval').value) || 10;

    const auditRes = ISA100Auditor.auditNetwork({
      devices,
      panId: 0x100A,
      maxLinkDistanceM: dist,
      environment: env,
      isSecurityEnabled: true,
      minPublishIntervalSec: interval,
      hasRedundantSm: true
    });

    document.getElementById('audit-score').innerText = `${auditRes.summary.overallScore}/100`;
    document.getElementById('audit-grade').innerText = auditRes.summary.grade;
    document.getElementById('audit-summary-counts').innerText =
      `${auditRes.summary.passCount} Pass / ${auditRes.summary.warnCount} Warn / ${auditRes.summary.failCount} Fail`;

    const container = document.getElementById('audit-results-container');
    container.innerHTML = '';

    auditRes.findings.forEach(f => {
      const rule = auditRes.rules.find(r => r.id === f.id);
      const item = document.createElement('div');
      item.className = 'audit-item';

      let statusClass = 'audit-pass';
      if (f.status === 'WARN') statusClass = 'audit-warn';
      if (f.status === 'FAIL') statusClass = 'audit-fail';

      item.innerHTML = `
        <span class="audit-status ${statusClass}">${f.status}</span>
        <div class="audit-content">
          <h4>[${f.id}] ${rule ? rule.name : f.id} (${rule ? rule.standard : 'STD'})</h4>
          <p>${f.details}</p>
        </div>
      `;
      container.appendChild(item);
    });
  }

  document.getElementById('btn-run-audit').addEventListener('click', runAudit);

  // TAB 5: Exporter
  document.getElementById('btn-generate-export').addEventListener('click', () => {
    const target = document.getElementById('export-target').value;
    let out = '';

    if (target === 'YOKOGAWA_YFGW') {
      out = `<?xml version="1.0" encoding="UTF-8"?>\n<!-- Yokogawa YFGW410 / YFGW510 Field Wireless Provisioning -->\n<ISA100_SUBNET pan_id="0x100A" network_id="4106">\n`;
      devices.forEach(d => {
        out += `  <DEVICE name="${d.name}" short_addr="0x${d.shortAddr.toString(16).padStart(4, '0').toUpperCase()}" role="${d.isRouter ? 'ROUTER' : 'IO_DEVICE'}"/>\n`;
      });
      out += `</ISA100_SUBNET>\n`;
    } else if (target === 'HONEYWELL_ONEWIRELESS') {
      out = `# Honeywell OneWireless Device Provisioning Table\nShort_Addr,Device_Name,Role,PAN_ID,AES_Key_Status\n`;
      devices.forEach(d => {
        out += `0x${d.shortAddr.toString(16).padStart(4, '0').toUpperCase()},"${d.name}",${d.isRouter ? 'ROUTER' : 'ENDPOINT'},0x100A,SECURED\n`;
      });
    } else if (target === 'PYTHON_SIM') {
      out = `#!/usr/bin/env python3\n# Python IEEE 802.15.4 / ISA100.11a Frame Simulator\nimport struct\n\n`;
      out += `def create_isa100_packet(pan_id=0x100A, src=0x0014, dest=0x0001, pv=75.0):\n`;
      out += `    fcf = 0x8861 # Data, Security, ACK, Short Addr\n`;
      out += `    hdr = struct.pack('<HBH H H H', fcf, 42, pan_id, dest, src, 0x0005)\n`;
      out += `    pv_data = struct.pack('>fB', pv, 0x80)\n`;
      out += `    return hdr + pv_data\n\n`;
      out += `pkt = create_isa100_packet(0x100A, 0x0014, 0x0001, 88.5)\n`;
      out += `print("Generated ISA100 Packet Bytes:", [hex(b) for b in pkt])\n`;
    }

    document.getElementById('export-output').value = out;
  });

  // Init
  renderPacket();
  renderLinksTable();
  recalculateRf();
  runAudit();
});
